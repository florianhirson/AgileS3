import java.sql.*;
import java.util.ArrayList;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/Select")
public class Select extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{

		String table=req.getParameter("table");
		String requete = "select * from"+table;
		String tmp ="";

		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.println("<!DOCTYPE html>");
		out.print("<html><head><title>servlet first </title>");

		out.print("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'></head><body><center>");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Test de ma Servlet</h1>");

		out.println("<a href=http://localhost:8080/vide/test.html>Retour vers index</a> ");

		Connection con = null;

		try{

			Class.forName("org.postgresql.Driver");

			String url = "jdbc:postgresql://psqlserv/n2p1";
			String nom = "barbetf";
			String mdp = "moi";
			con = DriverManager.getConnection(url,nom,mdp);

			Statement stmt = con.createStatement();
			stmt = con.createStatement();

			String query = "select * from "+table;
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int nCol = rsmd.getColumnCount();

			
		

			out.println("<h1>Base de Donnee : "+nCol+"</h1><table class=\"tata\">");
			tmp = "<tr>";
			for(int i=1; i <= nCol;i++){
				tmp+="<th>"+rsmd.getColumnName(i)+"</th>";
			}
			tmp+="<th>Suppression</th><th>Modification<th></th></tr>";
			out.println(tmp);
			while (rs.next()) 
			{
				

				String param = "<tr>";

				for(int i = 1; i <=nCol ;i++){	
					param +="<td>"+rs.getString(i)+"</td>";
				}
				
				

				
				out.println(param);
				out.println("<form action=Delete method=\"get\">");			
				for(int i = 1; i <=nCol ;i++){	
					out.println("<input type=hidden name=\""+rsmd.getColumnName(i)+"\" value=\""+rs.getString(i)+"\">");
				}
				out.println("<input type=hidden name=\"table\" value=\""+table+"\">");
				out.println("<td><input type=\"submit\" value=\"Suppr\"></td></form>");
			
				out.println("<form action=Update method=\"get\">");			
				for(int i = 1; i <=nCol ;i++){	
					out.println("<input type=hidden name=\""+rsmd.getColumnName(i)+"\" value=\""+rs.getString(i)+"\">");
				}
				out.println("<input type=hidden name=\"table\" value=\""+table+"\">");
				out.println("<td><input type=\"submit\" value=\"Mod\"></td></form></tr>");
				

			}

			
			out.println("<tr>");			
			out.println("<form action=Insert method=\"get\">");
			
				for(int i=1; i <= nCol;i++){
					out.println("<td>");
					out.println("<input type=\"text\" name=\""+rsmd.getColumnName(i)+"\">");
					out.println("</td>");
				}
			
			out.println(" </tr><tr><td colspan=\" "+nCol+" \">");
			out.println("<center><input type=\"submit\" value=\"Ajouter\"></center>");
			out.println("</td>");
			out.println("</tr>");			
			out.println("<input type=hidden name=\"table\" value=\""+table+"\">");

			out.println("</form>");

			out.println("</table>");
		}
		catch (Exception e) {
			out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
		}
		finally {	  
			try{
				con.close();	  
			}catch (Exception e) {
				out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
			}
		}





		out.println("</center></body></html>");
	}

}