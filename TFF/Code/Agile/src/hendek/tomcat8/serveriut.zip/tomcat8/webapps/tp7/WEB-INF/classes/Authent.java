
import java.sql.*;
import java.util.ArrayList;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/authent")
public class Authent extends HttpServlet
{
  public void service( HttpServletRequest req, HttpServletResponse res ) 
       throws ServletException, IOException
  {
	String table = "personne";
	String login=req.getParameter("login");
	String password=req.getParameter("mdp");
	
	

	res.setContentType("text/html;charset=UTF-8");
	PrintWriter out = res.getWriter();
	out.println("<!DOCTYPE html>");
	out.print("<html><head><title>Authentification</title>");

	out.println("<link rel=\"stylesheet\" href=\"../style2.css\">");
	out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'></head><body><center>");
	out.println("<META content=\"charset=UTF-8\"></head><body><center>");
	out.println("<h1>Authentification</h1>");

	out.println("<a href=../login.html>Retour</a> ");

	Connection con = null;

	try{

		Class.forName("org.postgresql.Driver");

		String url = "jdbc:postgresql://psqlserv/n2p1";
		String nom = "barbetf";
		String mdp = "moi";
		con = DriverManager.getConnection(url,nom,mdp);

		
		String requete = "select *  from "+table;
		
		requete += " WHERE login = '"+login+"' AND mdp = '"+password+"'";
		
		Statement stmt = con.createStatement();
		stmt = con.createStatement();

		ResultSet rs = stmt.executeQuery(requete);

		
		if(rs.next()){
			HttpSession session = req.getSession(true);
			session.setAttribute("login",login);
			res.sendRedirect("../menu.html");
			
		}else{
			res.sendRedirect("../login.html");;
		}
		
	}
	catch (Exception e) {
		out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
	}
	finally {	  
		try{
			con.close();	  
		}catch (Exception e) {
			out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
		}
	}





	out.println("</center></body></html>");
  }
}
