import java.util.*;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/servlet/Inserer")
public class Inserer extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:SS");
		String n,t,c,p,f;
		n=req.getParameter("n");
		t=req.getParameter("t");
		c=req.getParameter("c");
		p=req.getParameter("p");
		f=req.getParameter("f");
		
		
	
		
		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.print("<html><head><title>Insertion</title>");
	
		out.println("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Insertion</h1>");
		
		
		 Connection con = null;
	  
	  try{
		  Class.forName("org.postgresql.Driver");
		  
		  String url = "jdbc:postgresql://psqlserv/n2p1";
		  String nom = "barbetf";
		  String mdp = "moi";
		  con = DriverManager.getConnection(url,nom,mdp);	  
		  
		  Statement stmt = con.createStatement();
		  String query = "select * from salles";
		  ResultSet rs = stmt.executeQuery(query);
		  
		  while(rs.next()){
			  if(n==rs.getString(rs.findColumn("nom"))){
				//  footer += "<form action=Lister method=\"get\">";
				//	footer += "<input type=hidden name=\"error\" value=\"o\">";
				//	footer += "</form>";
					
				  res.sendRedirect("Lister")
				  
			  };
		  }
		  String ins="insert into salles Values ('"+n+"','"+t+"','"+c+"','"+p+"','"+f+"','"+req.getRemoteAddr() +"','"+fmt.format(new Date())+"')";
		  
		stmt.executeUpdate(ins);
		res.sendRedirect("Lister");
	  }
	  catch (Exception e) {
		  out.println("Oups ! (" + e.getMessage() + ")");
	  }
	  finally {	  
		  try{
			  con.close();	  
		  }catch (Exception e) {
			  out.println("Oups ! (" + e.getMessage() + ")");
		  }
	  }
  
		
		
		
		out.println("</center></body></html>");
	}

}