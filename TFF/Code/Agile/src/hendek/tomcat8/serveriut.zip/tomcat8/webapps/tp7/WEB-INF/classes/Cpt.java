// Servlet Test.java  de test de la configuration
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/Cpt")
public class Cpt extends HttpServlet
{
	int cpTT=0;
  public void service( HttpServletRequest req, HttpServletResponse res ) 
       throws ServletException, IOException
  {
	  HttpSession session = req.getSession( true );
	  Integer cpt = (Integer)session.getAttribute( "compteur" );
	  cpt = new Integer( cpt == null ? 1 : cpt.intValue() + 1 );
	  session.setAttribute( "compteur", cpt );
	  res.setContentType("text/html;charset=UTF-8");
	  PrintWriter out = res.getWriter();
	  
	    out.println("<!doctype html>");
	    cpTT++;
	  out.println("<html><head> <title>Implémenter un compteur</title>");
	  out.println(" </head> <body>");
	  out.println("<h1> vous avez accede : "+ cpt +" fois a cette page sur les "+cpTT+ " acces au total</h1>");
	  out.println("</body></html>");
  }
}
