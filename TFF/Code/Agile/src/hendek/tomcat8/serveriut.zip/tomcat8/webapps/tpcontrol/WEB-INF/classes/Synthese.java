import java.sql.*;
import java.util.ArrayList;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/Synthese")
public class Synthese extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{

		String tmp ="";
		String param ="";
		String menu = "<ul>";
		menu+="<li><a href=http://localhost:8080/tpcontrol/saisie.html>Formulaire</a></li>";
		menu+="<li><a href=http://localhost:8080/tpcontrol/servlet/Lister>Lister</a></li>";
		menu+="<li><a href=http://localhost:8080/tpcontrol/servlet/Synthese>Synthese</a></li>";
		menu+="</ul>";
		
		
		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.println("<!DOCTYPE html>");
		out.print("<html><head><title>Synthese</title>");

		out.print("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<META content=\"charset=UTF-8\"></head><body>");
		out.println("<h1>SallesBDD</h1>");
		out.println(menu);
		

		Connection con = null;

		try{

			Class.forName("org.postgresql.Driver");

			String url = "jdbc:postgresql://psqlserv/n2p1";
			String nom = "barbetf";
			String mdp = "moi";
			con = DriverManager.getConnection(url,nom,mdp);

			Statement stmt = con.createStatement();
			stmt = con.createStatement();

			String query = "select ip,count(*) as c,min(dat) as dm,max(dat) as dp from salles group by ip";
			ResultSet rs = stmt.executeQuery(query);


			
		

			out.println("<h1>Synthese </h1><table class=\"tata\">");
			tmp = "<tr>";

			tmp+="<th>ip</th><th>nbLineInsert</th><th>date max</th><th>date min</th>";
			
			
			tmp+="</tr>";
			out.println(tmp);
			while (rs.next()) 
			{
				

				param = "<tr>";

	              String i = rs.getString(rs.findColumn("ip"));
	              String nbline = rs.getString(rs.findColumn("c"));
	              String dP = rs.getString(rs.findColumn("dp"));
	              String dM = rs.getString(rs.findColumn("dm"));
	              
	              param+="<td><a href=http://localhost:8080/tpcontrol/servlet/Lister?ip="+i+">"+i ;
	              param+="</a>";
	              param+="</td><td><a href=http://localhost:8080/tpcontrol/servlet/Lister?ip="+i+">"+nbline;
	              param+="</a></td>";
	              param+="</td><td><a href=http://localhost:8080/tpcontrol/servlet/Lister?ip="+i+">"+dP;
	              param+="</a></td>";
	              param+="</td><td><a href=http://localhost:8080/tpcontrol/servlet/Lister?ip="+i+">"+dM;
	              param+="</a></td>";
	              
	              
	              
	              
				param+="</tr>";
				
				out.println(param);
			}
			

			
			
			out.println("</table>");
		}
		catch (Exception e) {
			out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
		}
		finally {	  
			try{
				con.close();	  
			}catch (Exception e) {
				out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
			}
		}





		out.println("</body></html>");
	}

}