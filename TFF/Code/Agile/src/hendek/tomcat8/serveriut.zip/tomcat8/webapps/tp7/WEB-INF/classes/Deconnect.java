
import java.sql.*;
import java.util.ArrayList;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/lecture")
public class Lecture extends HttpServlet
{
	public void service( HttpServletRequest req, HttpServletResponse res ) 
			throws ServletException, IOException
	{
		

		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.println("<!DOCTYPE html>");
		out.print("<html><head><title>Lecture</title>");

		out.println("<link rel=\"stylesheet\" href=\"../style2.css\">");
		out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'>");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Lecture </h1>");

		out.println("<a href=../login.html>Retour</a> ");


		HttpSession session = req.getSession(true);
		if (session.getAttribute("login")==null){
			res.sendRedirect("../login.html");
		}
		else
		{ 
			session.invalidate();	
		
		}










		out.println("</center></body></html>");
	}
}

