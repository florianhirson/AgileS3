import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/Second")
public class Second extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
	
				
				
		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.print("<html><head><title>servlet first </title>");
	
		out.print("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'></head><body><center>");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Test de ma Servlet</h1>");
		
		out.println("<a href=http://localhost:8080/vide/test.html>Retour vers index</a> ");
			
		Connection con = null;
		
	  try{
		  Class.forName("org.postgresql.Driver");
		  
		  String url = "jdbc:postgresql://psqlserv/n2p1";
		  String nom = "barbetf";
		  String mdp = "moi";
		  con = DriverManager.getConnection(url,nom,mdp);

		  Statement stmt = con.createStatement();
		  stmt = con.createStatement();
		  String query = "select ID,NOM,PRENOM from personne";
		  ResultSet rs = stmt.executeQuery(query);
		
		  out.println("<h1>Base de Donnee</h1><table class=\"tata\">");
		  out.println("<tr><th>nom</th><th>prenom</th><th>id</th></tr>");
		  while (rs.next()) 
		  {
			  String n = rs.getString(2); // nom
			  String p = rs.getString(3); // prenom
			  int a = rs.getInt(1);       // age
			 out.println("<tr><td>"+n + "</td><td> " + p + "</td><td> " + a+"</td></tr>");
		  }
		  out.println("<tr>");

		
			out.println("<form action=Insert method=\"get\">");
			out.println("<td>");
			out.println("<input type=\"text\" name=\"n\">");
			out.println("</td>");
			out.println("<td>");
			out.println("<input type=\"text\" name=\"p\">");
			out.println("</td>");
			out.println("<td>");
			out.println("<input type=\"submit\" value=\"Ajouter\">");
			out.println("</td>");
			out.println("</tr>");

			out.println("</form>");
		
		  out.println("</table>");
	  }
	  catch (Exception e) {
		  out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
	  }
	  finally {	  
		  try{
			  con.close();	  
		  }catch (Exception e) {
			  out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
		  }
	  }
	  

		
		
		
		out.println("</center></body></html>");
	}

}