import java.sql.*;
import java.util.ArrayList;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/Lister")
public class Lister extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{

		String tmp ="";
		String param ="";
		String menu = "<ul>";
		int x;
		if(req.getParameter("x")== null ){x=0;}
		else{
			x=Integer.parseInt(req.getParameter("x")) ;
			
		}
		String footer = "<footer>";
		
		String ip = "";
		String where ="";
		if(req.getParameter("ip") != null){
			ip = req.getParameter("ip");
			where = "where ip="+ip+"";
		}else{
			ip = "";
			where = "";
			
		}
	
		
		
		
		menu+="<li><a href=http://localhost:8080/tpcontrol/saisie.html>Formulaire</a></li>";
		menu+="<li><a href=http://localhost:8080/tpcontrol/servlet/Lister>Lister</a></li>";
		menu+="<li><a href=http://localhost:8080/tpcontrol/servlet/Synthese>Synthese</a></li>";
		menu+="</ul>";
		
	
		
	
		
		
		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.println("<!DOCTYPE html>");
		out.print("<html><head><title>Lister</title>");

		out.print("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<META content=\"charset=UTF-8\"></head><body>");
		out.println("<h1>SallesBDD</h1>");

		out.println(menu);

		Connection con = null;

		try{

			Class.forName("org.postgresql.Driver");

			String url = "jdbc:postgresql://psqlserv/n2p1";
			String nom = "barbetf";
			String mdp = "moi";
			con = DriverManager.getConnection(url,nom,mdp);

			Statement stmt = con.createStatement();
			stmt = con.createStatement();
	
			String query = "select * from salles limit 10 offset "+x+" "+where;
			ResultSet rs = stmt.executeQuery(query);
			String queryC = "select * from salles";
			

			
			int indice=0;

			out.println("<h1>Base de Donnee : salles </h1><table class=\"tata\">");
			tmp = "<tr>";

			tmp+="<th>nom</th><th>taille</th>";
			tmp+="<th>chaises</th><th>portes</th>";
			tmp+="<th>fenetres</th><th>ip</th>";
			tmp+="<th>dat</th>";
			tmp+="</tr>";
			out.println(tmp);
			while (rs.next()) 
			{
				

				param = "<tr>";

				  String n = rs.getString(1); 
	              String t = rs.getString(2); 
	              String c = rs.getString(3);
	              String p = rs.getString(4);
	              String f = rs.getString(5);
	              String i = rs.getString(6);
	              String d = rs.getString(7);
	              param+="<td>"+n ;
	              param+="</td><td>" +t;
	              param+="</td><td>" +c;
	              param+="</td><td>" +p;
	              param+="</td><td>" +f;
	              param+="</td><td>" +i;
	              param+="</td><td>" +d;
				param+="</tr>";
				out.println(param);
				
			}
			
			ResultSet rsC = stmt.executeQuery(queryC);
			while(rsC.next()){indice++;}
			
			int fin = indice-10;
			int next = x+10;
			int prec = x-10;
			if(next>fin)next=fin;
			
			if(prec<10)prec=0;		
			
			
			
			
			
			
			footer += "<form action=Lister method=\"get\">";
			footer += "<input type=hidden name=\"x\" value=\""+0+"\">";
			footer += "<input type=\"submit\" value=\"Debut\">";
			footer += "</form>";
			
			footer += "<form action=Lister method=\"get\">";
			footer += "<input type=hidden name=\"x\" value=\""+next+"\">";
			footer += "<input type=\"submit\" value=\"Suivant\">";
			footer += "</form>";
			
			footer += "<form action=Lister method=\"get\">";
			footer += "<input type=hidden name=\"x\" value=\""+prec+"\">";
			footer += "<input type=\"submit\" value=\"Precedent\">";
			footer += "</form>";
			
			footer += "<form action=Lister method=\"get\">";
			footer += "<input type=hidden name=\"x\" value=\""+fin+"\">";
			footer += "<input type=\"submit\" value=\"Fin\">";
			
			footer += "</form>";
			footer += "</footer>";
			
			out.println("</table>");
		}
		catch (Exception e) {
			out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
		}
		finally {	  
			try{
				con.close();	  
			}catch (Exception e) {
				out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
			}
		}


		

		out.println(footer);

		out.println("</body></html>");
	}

}