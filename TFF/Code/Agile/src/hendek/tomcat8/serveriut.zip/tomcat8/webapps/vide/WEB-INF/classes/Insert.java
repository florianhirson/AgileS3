import java.util.*;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/Insert")
public class Insert extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
	
		String table = req.getParameter("table");
		String ins="insert into "+table+" Values (";
		int tempIndex=0;
		
		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.print("<html><head><title>servlet first </title>");
	
		out.print("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'></head><body><center>");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Test de ma Servlet</h1>");
		
		out.println("<a href=Second>Lien vers DataBase</a>");
		
		 Connection con = null;
	  
	  try{
		  Class.forName("org.postgresql.Driver");
		  
		  String url = "jdbc:postgresql://psqlserv/n2p1";
		  String nom = "barbetf";
		  String mdp = "moi";
		  con = DriverManager.getConnection(url,nom,mdp);	  
		  
		  Statement stmt = con.createStatement();
		  String query = "select * from "+table;
		  ResultSet rs = stmt.executeQuery(query);
		  ResultSetMetaData rsmd = rs.getMetaData();
		  
		  
		  for(int i = 1; i < rsmd.getColumnCount();i++){
			  ins+="'"+req.getParameter(rsmd.getColumnName(i))+"',";
			  tempIndex=i;
		  }
		  tempIndex++;
		  ins+="'"+req.getParameter(rsmd.getColumnName(tempIndex))+"')";
		  
		stmt.executeUpdate(ins);
		res.sendRedirect("Select?table="+table);
	  }
	  catch (Exception e) {
		  out.println("Oups ! (" + e.getMessage() + ")");
	  }
	  finally {	  
		  try{
			  con.close();	  
		  }catch (Exception e) {
			  out.println("Oups ! (" + e.getMessage() + ")");
		  }
	  }
  
		
		
		
		out.println("</center></body></html>");
	}

}