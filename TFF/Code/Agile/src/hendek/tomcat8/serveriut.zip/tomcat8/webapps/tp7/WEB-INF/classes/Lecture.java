
import java.sql.*;
import java.util.ArrayList;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/lecture")
public class Lecture extends HttpServlet
{
	public void service( HttpServletRequest req, HttpServletResponse res ) 
			throws ServletException, IOException
	{
		

		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.println("<!DOCTYPE html>");
		out.print("<html><head><title>Lecture</title>");

		out.println("<link rel=\"stylesheet\" href=\"../style2.css\">");
		out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'>");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Lecture </h1>");

		out.println("<a href=../login.html>Retour</a> ");


		HttpSession session = req.getSession(true);
		if (session.getAttribute("login")==null){
			res.sendRedirect("../login.html");
		}
		else
		{ 
			Connection con = null;
			
			
			try{

				Class.forName("org.postgresql.Driver");

				String url = "jdbc:postgresql://psqlserv/n2p1";
				String nom = "barbetf";
				String mdp = "moi";
				con = DriverManager.getConnection(url,nom,mdp);
				String tmp = "";
				
				String requete = "select *  from personne";
				requete += " WHERE login = '"+session.getAttribute("login")+"'";
				
				Statement stmt = con.createStatement();
				stmt = con.createStatement();

				ResultSet rs = stmt.executeQuery(requete);
				if(rs.next()){
					tmp+="<h1>Coordonnee de ";
					tmp+=rs.getString("login")+"</h1>";
					
					tmp+="<p> Nom : "+rs.getString("nom")+"</p>";
					tmp+="<p> Prenom : "+rs.getString("prenom")+"</p>";
					tmp+="<p> Adresse : "+rs.getString("adresse")+"</p>";
					tmp+="<p> Mail : "+rs.getString("email")+"</p>";
					tmp+="<p> tel. : "+rs.getString("tel")+"</p>";
					tmp+="<p> Date de Naissance : "+rs.getString("datenaiss")+"</p>";
					out.println(tmp);
				}
				

			}
			catch (Exception e) {
				out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
			}
			finally {	  
				try{
					con.close();	  
				}catch (Exception e) {
					out.println("<h1>Oups ! (" + e.getMessage() + ")</h1>");
				}
			}
		
		
		
		
		
		}










		out.println("</center></body></html>");
	}
}

