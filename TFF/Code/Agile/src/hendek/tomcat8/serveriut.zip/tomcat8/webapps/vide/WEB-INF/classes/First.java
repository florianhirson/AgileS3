import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/servlet/First")
public class First extends HttpServlet{

	public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
	
		
		int col=Integer.parseInt(req.getParameter("nbCol"));
		
		res.setContentType("text/html;charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.print("<html><head><title>servlet first </title>");
	
		out.print("<link rel=\"stylesheet\" href=\"../style.css\">");
		out.println("<link href=\'https://fonts.googleapis.com/css?family=Raleway:700\' rel=\'stylesheet\' type=\'text/css\'></head><body><center>");
		out.println("<META content=\"charset=UTF-8\"></head><body><center>");
		out.println("<h1>Test de ma Servlet</h1>");
		out.println("<h2> Super ! ca marche </h2>");
		out.println("<a href=http://localhost:8080/vide/test.html>Retour vers index</a> ");
		out.println("<table class=\"tata\">");
		for(int i=0 ;i<256/col;i++){
		
			out.println("<tr>");
			for(int j = 0; j <col;j++){
				if(i == 0)out.println("<th>caractere</th><th>decimal</th>");
				else
				out.println("<td>"+((char)(i+j*(256/col)))+"</td><td>"+((i+j*(256/col)))+"</td>");
				
			}
			
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("<a href=http://localhost:8080/vide/test.html>Retour vers index</a> ");
		
		
		out.println("</center></body></html>");
	}

}